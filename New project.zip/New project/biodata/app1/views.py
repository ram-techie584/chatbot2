from django.shortcuts import render



def welcome(request):
    return render(request, 'app1/welcome.html')  # shows only banner


def home(request):
    return render(request, 'app1/home.html')

def skills(request):
    return render(request, 'app1/skills.html')

def projects(request):
    return render(request, 'app1/projects.html')

def experience(request):
    return render(request, 'app1/experience.html')

def education(request):
    return render(request, 'app1/education.html')

def contact(request):
    return render(request, 'app1/contact.html')